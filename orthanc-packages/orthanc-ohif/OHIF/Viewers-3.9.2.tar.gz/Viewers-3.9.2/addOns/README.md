# External Dependencies

This module contains optional dependencies and external dependencies for including in OHIF, such as the DICOM Microscopy Viewer component.  
