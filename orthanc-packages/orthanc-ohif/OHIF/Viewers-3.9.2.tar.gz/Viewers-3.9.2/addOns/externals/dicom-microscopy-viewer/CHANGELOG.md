# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [3.9.2](https://github.com/OHIF/Viewers/compare/v3.9.1...v3.9.2) (2024-12-03)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





## [3.9.1](https://github.com/OHIF/Viewers/compare/v3.9.0...v3.9.1) (2024-11-13)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.111...v3.9.0) (2024-11-12)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.111](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.110...v3.9.0-beta.111) (2024-11-12)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.110](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.109...v3.9.0-beta.110) (2024-11-11)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.109](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.108...v3.9.0-beta.109) (2024-11-08)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.108](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.107...v3.9.0-beta.108) (2024-11-07)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.107](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.106...v3.9.0-beta.107) (2024-11-06)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.106](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.105...v3.9.0-beta.106) (2024-11-06)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.105](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.104...v3.9.0-beta.105) (2024-11-05)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.104](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.103...v3.9.0-beta.104) (2024-10-30)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.103](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.102...v3.9.0-beta.103) (2024-10-29)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.102](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.101...v3.9.0-beta.102) (2024-10-29)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.101](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.100...v3.9.0-beta.101) (2024-10-18)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.100](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.99...v3.9.0-beta.100) (2024-10-17)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.99](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.98...v3.9.0-beta.99) (2024-10-17)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.98](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.97...v3.9.0-beta.98) (2024-10-15)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.97](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.96...v3.9.0-beta.97) (2024-10-11)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.96](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.95...v3.9.0-beta.96) (2024-10-10)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.95](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.94...v3.9.0-beta.95) (2024-10-08)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.94](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.93...v3.9.0-beta.94) (2024-10-04)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.93](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.92...v3.9.0-beta.93) (2024-10-04)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.92](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.91...v3.9.0-beta.92) (2024-10-01)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.91](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.90...v3.9.0-beta.91) (2024-10-01)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.90](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.89...v3.9.0-beta.90) (2024-09-30)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.89](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.88...v3.9.0-beta.89) (2024-09-27)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.88](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.87...v3.9.0-beta.88) (2024-09-24)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.87](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.86...v3.9.0-beta.87) (2024-09-19)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.86](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.85...v3.9.0-beta.86) (2024-09-19)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.85](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.84...v3.9.0-beta.85) (2024-09-17)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.84](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.83...v3.9.0-beta.84) (2024-09-12)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.83](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.82...v3.9.0-beta.83) (2024-09-11)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.82](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.81...v3.9.0-beta.82) (2024-09-05)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.81](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.80...v3.9.0-beta.81) (2024-08-27)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.80](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.79...v3.9.0-beta.80) (2024-08-16)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.79](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.78...v3.9.0-beta.79) (2024-08-16)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.78](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.77...v3.9.0-beta.78) (2024-08-15)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.77](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.76...v3.9.0-beta.77) (2024-08-15)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.76](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.75...v3.9.0-beta.76) (2024-08-08)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.75](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.74...v3.9.0-beta.75) (2024-08-07)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.74](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.73...v3.9.0-beta.74) (2024-08-06)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.73](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.72...v3.9.0-beta.73) (2024-08-02)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.72](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.71...v3.9.0-beta.72) (2024-07-31)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.71](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.70...v3.9.0-beta.71) (2024-07-30)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.70](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.69...v3.9.0-beta.70) (2024-07-30)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.69](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.68...v3.9.0-beta.69) (2024-07-27)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.68](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.67...v3.9.0-beta.68) (2024-07-26)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.67](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.66...v3.9.0-beta.67) (2024-07-26)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.66](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.65...v3.9.0-beta.66) (2024-07-24)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.65](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.64...v3.9.0-beta.65) (2024-07-23)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.64](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.63...v3.9.0-beta.64) (2024-07-19)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.63](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.62...v3.9.0-beta.63) (2024-07-10)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.62](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.61...v3.9.0-beta.62) (2024-07-09)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.61](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.60...v3.9.0-beta.61) (2024-07-09)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.60](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.59...v3.9.0-beta.60) (2024-07-09)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.59](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.58...v3.9.0-beta.59) (2024-07-05)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.58](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.57...v3.9.0-beta.58) (2024-07-04)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.57](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.56...v3.9.0-beta.57) (2024-07-02)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.56](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.55...v3.9.0-beta.56) (2024-07-02)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.55](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.54...v3.9.0-beta.55) (2024-06-28)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.54](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.53...v3.9.0-beta.54) (2024-06-28)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.53](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.52...v3.9.0-beta.53) (2024-06-28)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.52](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.51...v3.9.0-beta.52) (2024-06-27)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.51](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.50...v3.9.0-beta.51) (2024-06-27)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.50](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.49...v3.9.0-beta.50) (2024-06-26)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.49](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.48...v3.9.0-beta.49) (2024-06-26)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.48](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.47...v3.9.0-beta.48) (2024-06-25)

**Note:** Version bump only for package @externals/dicom-microscopy-viewer





# [3.9.0-beta.47](https://github.com/OHIF/Viewers/compare/v3.9.0-beta.46...v3.9.0-beta.47) (2024-06-21)


### Bug Fixes

* Allow the mode setup/creation to be async, and provide a few more values to extension/app config/mode setup. ([#4016](https://github.com/OHIF/Viewers/issues/4016)) ([88575c6](https://github.com/OHIF/Viewers/commit/88575c6c09fd778a31b2f91524163ce65d1639dd))
