// We need to define a UID for this extension as a device, and it should be the same for all saves:

const uid = '2.25.285241207697168520771311899641885187923';

export default uid;
