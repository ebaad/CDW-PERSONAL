export default function toArray(item) {
  return Array.isArray(item) ? item : [item];
}
