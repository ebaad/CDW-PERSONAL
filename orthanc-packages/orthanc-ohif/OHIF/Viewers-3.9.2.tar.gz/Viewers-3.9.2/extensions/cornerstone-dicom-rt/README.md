# dicom-rt
## Description

DICOM RT read workflow. This extension will allow you to load a DICOM RTSS image
and display it in OHIF.


## Author

OHIF

## License
MIT
