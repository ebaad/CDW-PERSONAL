module.exports = require('../../babel.config.js');
