const RENDERING_ENGINE_ID = 'OHIFCornerstoneRenderingEngine';

export { RENDERING_ENGINE_ID };
