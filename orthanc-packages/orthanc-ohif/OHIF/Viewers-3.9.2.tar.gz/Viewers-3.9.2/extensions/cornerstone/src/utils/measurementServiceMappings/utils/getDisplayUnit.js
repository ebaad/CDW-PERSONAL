const getDisplayUnit = unit => (unit == null ? '' : unit);

export default getDisplayUnit;
