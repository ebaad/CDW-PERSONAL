import SyncGroupService from './SyncGroupService';

export default SyncGroupService;
