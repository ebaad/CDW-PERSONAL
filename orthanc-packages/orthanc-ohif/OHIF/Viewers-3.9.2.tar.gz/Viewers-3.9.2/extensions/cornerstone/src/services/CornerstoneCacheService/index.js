import CornerstoneCacheService from './CornerstoneCacheService';

export default CornerstoneCacheService;
