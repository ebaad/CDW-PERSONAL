import CinePlayer from './CinePlayer';

export default CinePlayer;
