const supportedTools = [
  'Length',
  'EllipticalROI',
  'CircleROI',
  'Bidirectional',
  'ArrowAnnotate',
  'Angle',
  'CobbAngle',
  'Probe',
  'RectangleROI',
  'PlanarFreehandROI',
  'SplineROI',
  'LivewireContour',
  'UltrasoundDirectionalTool',
  'SCOORD3DPoint',
];

export default supportedTools;
