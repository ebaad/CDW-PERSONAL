import packageJson from '../package.json';

const id = packageJson.name;

export { id };
