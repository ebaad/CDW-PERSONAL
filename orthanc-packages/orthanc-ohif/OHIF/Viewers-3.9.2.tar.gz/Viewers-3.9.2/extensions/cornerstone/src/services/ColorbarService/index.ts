import ColorbarService from './ColorbarService';
export default ColorbarService;
