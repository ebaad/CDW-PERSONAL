import SegmentationService from './SegmentationService';

export default SegmentationService;
