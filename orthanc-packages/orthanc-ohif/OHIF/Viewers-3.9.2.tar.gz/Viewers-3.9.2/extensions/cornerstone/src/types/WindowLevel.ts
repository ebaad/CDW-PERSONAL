export type WindowLevelPreset = {
  description: string;
  window: string;
  level: string;
};
