import ToolGroupService from './ToolGroupService';

export default ToolGroupService;
