import packageJson from '../package.json';

const id = packageJson.name;
const SOPClassHandlerName = 'dynamic-volume';

export { id, SOPClassHandlerName };
