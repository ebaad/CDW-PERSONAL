# DICOM Encapsulated PDF
This extension adds support for displaying DICOM encapsulated PDF documents.

The extension is a "standard" extension in that it is installed and available
by default.
