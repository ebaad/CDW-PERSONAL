type actionIcon = {
  id: string;
  iconName: string;
  value: boolean;
};

export type { actionIcon };
