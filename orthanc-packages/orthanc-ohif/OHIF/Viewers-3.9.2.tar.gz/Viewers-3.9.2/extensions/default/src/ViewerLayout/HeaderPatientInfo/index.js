import HeaderPatientInfo from './HeaderPatientInfo';

export default HeaderPatientInfo;
