type viewPreset = {
  id: string;
  iconName: string;
  selected: boolean;
};

export type { viewPreset };
