import type { actionIcon } from '../types/actionsIcon';

const defaultActionIcons = [
  {
    id: 'settings',
    iconName: 'Settings',
    value: false,
  },
] as actionIcon[];

export { defaultActionIcons };
