export { addIcon } from './addIcon';
