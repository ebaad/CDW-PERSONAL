import React from 'react';

export default function ToolbarDivider() {
  return <span className="border-common-dark mx-2 h-8 w-4 self-center border-l" />;
}
