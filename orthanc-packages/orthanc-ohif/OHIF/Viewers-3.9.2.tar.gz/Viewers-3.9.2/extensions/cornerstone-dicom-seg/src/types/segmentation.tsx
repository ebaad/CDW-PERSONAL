export enum SegmentationPanelMode {
  Expanded = 'expanded',
  Dropdown = 'dropdown',
}
