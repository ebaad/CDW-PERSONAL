# dicom-pmap
## Description

DICOM PMAP read workflow. This extension will allow you to load a DICOM Parametric
Map image and display it on OHIF.

## Author

OHIF

## License
MIT
