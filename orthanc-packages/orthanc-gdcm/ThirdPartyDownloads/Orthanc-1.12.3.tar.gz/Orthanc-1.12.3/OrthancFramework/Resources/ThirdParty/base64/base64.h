#include <string>

void base64_encode(std::string& result, const std::string& stringToEncode);
void base64_decode(std::string& result, const std::string& s);
