const events = {
  name: 'cornerstone-core'
};

export default events;
