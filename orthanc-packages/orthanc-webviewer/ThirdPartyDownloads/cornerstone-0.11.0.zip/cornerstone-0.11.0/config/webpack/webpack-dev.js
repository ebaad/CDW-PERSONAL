module.exports = require('./webpack-base');
